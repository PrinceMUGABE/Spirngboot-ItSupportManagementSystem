package com.example.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Request_Tbl")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Request {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  int id;
    private String fullnames;
    private String address;
    @Id
    private String phone;
    private String issue;



}
