package com.example.serviceImplementation;

import com.example.model.Request;
import com.example.repository.RequestRepository;
import com.example.service.RequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RequestServiceImplementation implements RequestService {
    @Autowired
    RequestRepository repo;
    @Override
    public Request saveRequest(Request request) {
        return repo.save(request);
    }

    @Override
    public List<Request> displayRequests() {
        return repo.findAll();
    }

    @Override
    public Request findRequestById(Request request) {
        return repo .findById(request.getPhone()).orElse(null);
    }

    @Override
    public Request updateRequest(Request request) {
        Request savedRequest = repo.findById(request.getPhone()).orElse(null);
        if (savedRequest != null) {
            savedRequest.setFullnames(request.getFullnames());
            savedRequest.setAddress(request.getAddress());
            savedRequest.setIssue(request.getIssue());

            return repo.save(savedRequest);
        }
        else {
            return repo.save(request);
        }

    }

    @Override
    public void deleteRequest(Request request) {
        Request savedRequest = repo.findById(request.getPhone()).orElse(null);
        if (savedRequest != null) {
            repo.delete(savedRequest);
        }

    }
}
