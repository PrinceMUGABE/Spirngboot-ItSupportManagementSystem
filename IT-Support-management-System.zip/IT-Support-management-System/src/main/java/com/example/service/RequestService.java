package com.example.service;

import com.example.model.Request;

import java.util.List;

public interface RequestService {
    Request saveRequest(Request request);
    List<Request> displayRequests();
    Request findRequestById(Request request);
    Request updateRequest(Request request);
    void deleteRequest(Request request);
}
