package com.example.controller;

import com.example.model.Request;
import com.example.serviceImplementation.RequestServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class RequestController {
    @Autowired
    RequestServiceImplementation service;

    @GetMapping("/request/new")
    public String showRequestForm(Model model){
        Request request = new Request();
        model.addAttribute("request", request);
        model.addAttribute("pageTitle", "Create your request here");

        return "requestForm";
    }
    @PostMapping("/request/save")
    public String saveRequest(Request request, Model model, RedirectAttributes ra){
        try {
            Request savedRequest = service.saveRequest(request);
            model.addAttribute("request", savedRequest);
            ra.addFlashAttribute("message", "Your request sent successfully");

        }catch (Exception ex){
            ex.printStackTrace();
        }
        return "redirect:/request/new";
    }
    @GetMapping("/request/list")
    public String displayRequest(Model model){
        List<Request> listRequest = service.displayRequests();
        model.addAttribute("listRequest", listRequest);

        return "requestcrud";
    }

    @GetMapping("/request/edit/{phone}")
    public String editRequest(@PathVariable("phone") Request phone, Model model, RedirectAttributes ra){
        try {
            Request savedRequest = service.findRequestById(phone);
            model.addAttribute("request", savedRequest);
            model.addAttribute("pageTitle","edit request");
            ra.addFlashAttribute("message", "Your request updated successfully");
            return "requestForm";
        }catch (Exception ex){
            ex.printStackTrace();
        }

        return "redirect:/request/list";
    }

    @GetMapping("/request/delete/{phone}")
    public String deleteRequest(@PathVariable("phone") Request phone, Model model, RedirectAttributes ra){
        try{
            service.deleteRequest(phone);
            ra.addFlashAttribute("message", "Request successfully deleted");
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return "redirect:/request/list";
    }

}
